<?php
App::uses('AppController', 'Controller');
 
class MySampleDatasController extends AppController {
  public $scaffold;
}
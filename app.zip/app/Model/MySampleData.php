<?php
App::uses('AppModel', 'Model');
 
class MySampleData extends AppModel {
     
}